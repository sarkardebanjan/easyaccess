package com.example.demodd.model;

import jakarta.persistence.*;

@Entity
@Table(name = "address")
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String line1;
    private String city;
    private String state;
    private String zip;

    @ManyToOne
    @JoinColumn(name = "person_id")
    private Person owner;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getLine1() { return line1; }
    public void setLine1(String line1) { this.line1 = line1; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
    public String getZip() { return zip; }
    public void setZip(String zip) { this.zip = zip; }
    public Person getOwner() { return owner; }
    public void setOwner(Person owner) { this.owner = owner; }
}
